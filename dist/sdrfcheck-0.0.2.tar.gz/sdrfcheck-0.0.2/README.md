# sdrfcheck

Library and tool to validate an sdrf (Sample and Data Relationship Format) for proteomics. The file format specification can be found here
(https://github.com/bigbio/proteomics-metadata-standard)




